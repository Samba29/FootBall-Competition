-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Sam 05 Janvier 2019 à 00:40
-- Version du serveur :  5.7.14
-- Version de PHP :  5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `tp201`
--

-- --------------------------------------------------------

--
-- Structure de la table `equipe`
--

CREATE TABLE `equipe` (
  `ID` int(11) NOT NULL,
  `Nom` varchar(30) NOT NULL,
  `ImageUrl` text NOT NULL,
  `NombreMatchJouer` int(11) NOT NULL DEFAULT '0',
  `BM` int(11) NOT NULL DEFAULT '0',
  `BE` int(11) NOT NULL DEFAULT '0',
  `DF` int(11) NOT NULL DEFAULT '0',
  `Nulls` int(11) DEFAULT '0',
  `Victoires` int(11) NOT NULL DEFAULT '0',
  `Defaites` int(11) NOT NULL DEFAULT '0',
  `Groupe` text NOT NULL,
  `Points` int(2) NOT NULL DEFAULT '0',
  `Participation` tinyint(1) NOT NULL DEFAULT '0',
  `Choisi` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `equipe`
--

INSERT INTO `equipe` (`ID`, `Nom`, `ImageUrl`, `NombreMatchJouer`, `BM`, `BE`, `DF`, `Nulls`, `Victoires`, `Defaites`, `Groupe`, `Points`, `Participation`, `Choisi`) VALUES
(1, 'Algerie', 'drapeau/dp_ALG.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(2, 'Burkina Faso', 'drapeau/dp_BF.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(3, 'Cameroun', 'drapeau/dp_CMR.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(4, 'Cote d\'ivoire', 'drapeau/dp_CI.png', 3, 3, 8, -5, 0, 0, 3, 'A', 0, 1, 1),
(5, 'Comores', 'drapeau/dp_COM.png', 3, 6, 6, 0, 0, 2, 1, 'A', 6, 1, 1),
(6, 'Ethiopie', 'drapeau/dp_ETH.png', 3, 7, 3, 4, 0, 3, 0, 'A', 9, 1, 1),
(7, 'Erythrée', 'drapeau/dp_ERY.png', 3, 7, 6, 1, 0, 1, 2, 'A', 3, 1, 1),
(8, 'Ghana', 'drapeau/dp_GHA.png', 3, 6, 6, 0, 0, 1, 2, 'B', 3, 1, 1),
(9, 'Gambie', 'drapeau/dp_GAM.png', 3, 7, 6, 1, 0, 2, 1, 'B', 6, 1, 1),
(10, 'Guinee equatoriale', 'drapeau/dp_GE.png', 3, 7, 5, 2, 0, 2, 1, 'B', 6, 1, 1),
(11, 'Guinee bissau', 'drapeau/dp_GB.png', 3, 6, 9, -3, 0, 1, 2, 'B', 3, 1, 1),
(12, 'Kenya', 'drapeau/dp_KEN.png', 3, 6, 4, 2, 0, 2, 1, 'C', 6, 1, 1),
(13, 'Libye', 'drapeau/dp_LIB.png', 3, 8, 7, 1, 0, 2, 1, 'C', 6, 1, 1),
(14, 'Botswana', 'drapeau/dp_BOT.png', 2, 5, 5, 0, 0, 1, 1, 'C', 3, 1, 1),
(15, 'Botswanga', 'drapeau/dp_BOTW.png', 2, 3, 6, -3, 0, 0, 2, 'C', 0, 1, 1),
(16, 'Nigeria', 'drapeau/dp_NIG.png', 3, 6, 4, 2, 0, 2, 1, 'D', 6, 1, 1),
(17, 'Tchad', 'drapeau/dp_TCH.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(19, 'Djibouti', 'drapeau/dp_DJI.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(20, 'Egypte', 'drapeau/dp_EGY.png', 3, 7, 6, 1, 0, 2, 1, 'D', 6, 1, 1),
(30, 'Somalie', 'drapeau/dp_SOM', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(32, 'Guinée', 'drapeau/dp_GUI.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(33, 'Mauritanie', 'drapeau/dp_MAU', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(34, 'Namibie', 'drapeau/dp_NAM', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(36, 'République du Congo', 'drapeau/dp_RC', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(37, 'République Centrafricaine', 'drapeau/dp_RCA', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(38, 'Zaïre', 'drapeau/dp_ZAI', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(39, 'Sierra Léone', 'drapeau/dp_SLE', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(41, 'Tanzanie', 'drapeau/dp_TAN', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(42, 'Tunisie', 'drapeau/dp_TUN', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(43, 'Zambie', 'drapeau/dp_ZAM', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(44, 'Bï¿½nin', 'drapeau/dp_BEN.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(45, 'Burundi', 'drapeau/dp_BUR.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(46, 'Cap Vert', 'drapeau/dp_CVE.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(47, 'Gabon', 'drapeau/dp_GAB.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(48, 'Lesotho', 'drapeau/dp_LES.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(49, 'Libï¿½ria', 'drapeau/dp_LBA.png', 2, 3, 6, -3, 0, 0, 2, 'D', 0, 1, 1),
(50, 'Madagascar', 'drapeau/dp_MAD', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(51, 'Mali', 'drapeau/dp_MAL', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(52, 'Maroc', 'drapeau/dp_MAR', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(54, 'Malawi', 'drapeau/dp_MAW', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(55, 'Mozambique', 'drapeau/dp_MOZ', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(56, 'Niger', 'drapeau/dp_NGR.png', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(57, 'Rwanda', 'drapeau/dp_RWA', 2, 4, 4, 0, 0, 1, 1, 'D', 3, 1, 1),
(58, 'Sénegal', 'drapeau/dp_SEN', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(59, 'Seychelles', 'drapeau/dp_SEY', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(60, 'Soudan', 'drapeau/dp_SOU', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(61, 'Sao Tomé et Principe', 'drapeau/dp_STP', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(62, 'Togo', 'drapeau/dp_TOG', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(63, 'Swaziland', 'drapeau/dp_SWA', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0),
(64, 'Zimbabwe', 'drapeau/dp_ZIM', 0, 0, 0, 0, 0, 0, 0, 'NONE', 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `joueur`
--

CREATE TABLE `joueur` (
  `ID` int(11) NOT NULL,
  `Nom` varchar(30) NOT NULL,
  `Age` tinyint(2) NOT NULL,
  `Nationalite` int(11) NOT NULL,
  `NombreBut` tinyint(4) NOT NULL,
  `Poste` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table qui contient les joueurs';

--
-- Contenu de la table `joueur`
--

INSERT INTO `joueur` (`ID`, `Nom`, `Age`, `Nationalite`, `NombreBut`, `Poste`) VALUES
(1, 'Milla', 20, 3, 20, ''),
(2, 'Seydou', 40, 1, 2, '');

-- --------------------------------------------------------

--
-- Structure de la table `match`
--

CREATE TABLE `match` (
  `ID` int(11) NOT NULL,
  `Jour` int(10) NOT NULL,
  `Equipe1` int(11) NOT NULL,
  `Equipe2` int(11) NOT NULL,
  `Buts_Equipe1` int(11) NOT NULL DEFAULT '0',
  `Buts_Equipe2` int(11) NOT NULL DEFAULT '0',
  `Vainqueur` int(11) DEFAULT NULL,
  `Passer` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `match`
--

INSERT INTO `match` (`ID`, `Jour`, `Equipe1`, `Equipe2`, `Buts_Equipe1`, `Buts_Equipe2`, `Vainqueur`, `Passer`) VALUES
(7013, 1, 4, 5, 1, 2, 5, 1),
(7014, 2, 8, 9, 1, 2, 9, 1),
(7015, 3, 12, 13, 2, 1, 12, 1),
(7016, 4, 16, 20, 2, 1, 16, 1),
(7017, 5, 4, 6, 1, 2, 6, 1),
(7018, 6, 8, 10, 1, 2, 10, 1),
(7019, 7, 12, 14, 1, 2, 14, 1),
(7020, 8, 16, 49, 3, 1, 16, 1),
(7021, 9, 4, 7, 1, 4, 7, 1),
(7022, 10, 8, 11, 4, 2, 8, 1),
(7023, 11, 12, 15, 3, 1, 12, 1),
(7024, 12, 16, 57, 1, 2, 57, 1),
(7025, 13, 5, 6, 1, 3, 6, 1),
(7026, 14, 9, 10, 3, 2, 9, 1),
(7027, 15, 13, 14, 4, 3, 13, 1),
(7028, 16, 20, 49, 3, 2, 20, 1),
(7029, 17, 5, 7, 3, 2, 5, 1),
(7030, 18, 9, 11, 2, 3, 11, 1),
(7031, 19, 13, 15, 3, 2, 13, 1),
(7032, 20, 20, 57, 3, 2, 20, 1),
(7033, 21, 6, 7, 2, 1, 6, 1),
(7034, 22, 10, 11, 3, 1, 10, 1),
(7035, 23, 14, 15, 0, 0, NULL, 0),
(7036, 24, 49, 57, 0, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `Login` varchar(10) NOT NULL,
  `Password` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`Login`, `Password`) VALUES
('', '');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `equipe`
--
ALTER TABLE `equipe`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `joueur`
--
ALTER TABLE `joueur`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Nationalite` (`Nationalite`);

--
-- Index pour la table `match`
--
ALTER TABLE `match`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ID_Equipe` (`Equipe1`),
  ADD KEY `Equipe2` (`Equipe2`),
  ADD KEY `Vainqueur` (`Vainqueur`),
  ADD KEY `Vainqueur_2` (`Vainqueur`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `equipe`
--
ALTER TABLE `equipe`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT pour la table `joueur`
--
ALTER TABLE `joueur`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `match`
--
ALTER TABLE `match`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7037;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `joueur`
--
ALTER TABLE `joueur`
  ADD CONSTRAINT `joueur_ibfk_1` FOREIGN KEY (`Nationalite`) REFERENCES `equipe` (`ID`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `match`
--
ALTER TABLE `match`
  ADD CONSTRAINT `match_ibfk_1` FOREIGN KEY (`Equipe1`) REFERENCES `equipe` (`ID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `match_ibfk_2` FOREIGN KEY (`Equipe2`) REFERENCES `equipe` (`ID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `match_ibfk_3` FOREIGN KEY (`Vainqueur`) REFERENCES `equipe` (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
