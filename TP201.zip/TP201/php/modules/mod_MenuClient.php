	<ul class="nav">
			<a href=""><li>Classement des �quipes par Pool</li></a>
			<a href=""><li>Affiche des matchs pr�cedents</li></a>
			<a href=""><li>Affiche des prochains matchs</li></a>
			<a href=""><li>Connexion</li></a>
		</ul>