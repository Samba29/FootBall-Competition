	<?php
		Require_Once "Configuration.php";
		ManageTeam("noDisplay_ModificationTeam.php");
	?>
