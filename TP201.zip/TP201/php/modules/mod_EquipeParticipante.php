	<?php
		Require_Once "Configuration.php";
		PreviewTeamSelectionned();
	?>
