 <span class="affichagePool">
            <?php 
                PrintgetTeamPool("A"); 
            ?>
        </span>
        <span class="affichagePool">
            <?php 
                PrintgetTeamPool("B"); 
            ?>            
        </span>
        <span class="affichagePool">
            <?php 
                PrintgetTeamPool("C"); 
            ?>
        </span>
        <span class="affichagePool">
            <?php 
                PrintgetTeamPool("D"); 
            ?>
        </span>