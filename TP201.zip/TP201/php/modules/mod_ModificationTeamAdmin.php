<?php
	Require_Once "Configuration.php";
	ModifTeam($_POST['file']);
?>