<?php
require_once "Configuration.php";
setScore($_POST['score1'], $_POST['score2'], $_POST['IDMatch'], $_POST['IDEquipe1'], $_POST['IDEquipe2'], $_POST['file']);
?>