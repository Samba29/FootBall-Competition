<?php
	Require_Once "modules/mod_ModificationTeamAdmin.php";
	ModifTeam($_POST['file']);  
?>