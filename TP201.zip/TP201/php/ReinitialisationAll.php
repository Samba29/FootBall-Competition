<?php
Require_Once "Configuration.php";

ReinitialiseAll($_GET['lien']);
?>