<?php
	Require_Once "Configuration.php";
	InsertTeam();
?>