<?php
Require_Once "heart/generateDataFinale.php";
Require_Once "heart/generateDataHalf.php";
Require_Once "heart/DataPool.php";
Require_Once "heart/FinaleQuarter.php";
Require_Once "heart/generateDataShort.php";
Require_Once "heart/match.php";
Require_Once "heart/team.php";
Require_Once "heart/connect.php";
Require_Once "heart/FunctionReinitialisation.php";

?>