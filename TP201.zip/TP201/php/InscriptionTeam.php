<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" type="text/css" media="screen" href="../css/Administration1.css" />
</head>
<body>
	<?php include('modules/mod_MenuAdmin.php')?>
	<?php
	include('modules/mod_FormulaireInscription.php')
	?>
</body>
</html>